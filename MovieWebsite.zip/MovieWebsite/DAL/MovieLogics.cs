﻿using MovieWebsite.EF;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace MovieWebsite.DAL
{
    public class MovieLogics
    {
        DeltaxAssignmentEntities db = new DeltaxAssignmentEntities();
        SqlConnection con = new SqlConnection(WebConfigurationManager.ConnectionStrings["DeltaConnection"].ConnectionString);


        public DataTable GetAllActors()
        {

            SqlCommand command = new SqlCommand("sp_AllActor", con);
            command.CommandType = System.Data.CommandType.StoredProcedure;

            con.Open();

            var adapter = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();
            DataTable dr = ds.Tables[0];
            return dr;
        }

        public DataTable GetAllMovies()
        {
            SqlCommand command = new SqlCommand("sp_DisplayAllMovie", con);
            command.CommandType = System.Data.CommandType.StoredProcedure;

            con.Open();

            var adapter = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();
            DataTable Movies = ds.Tables[0];
            return Movies;
        }

        public DataTable GetMovie(int id)
        {
            SqlCommand command = new SqlCommand("sp_DisplayOneMovie", con);
            
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add("@MovieId", SqlDbType.BigInt).Value = id;
            con.Open();

            var adapter = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            con.Close();
            DataTable Movies = ds.Tables[0];
            return Movies;
        }
        public int AddProducer(Producer pro)
        {
            db.Producers.Add(pro);
            int result = db.SaveChanges();
            return result;
        }

        public int AddActor(Actor actor)
        {
            db.Actors.Add(actor);
            int result = db.SaveChanges();
            return result;
        }
        public List<Producer> GetAllProducer()
        { 
        List<Producer> producer=new List<Producer>();
        producer = db.Producers.ToList();
        return producer;
        }

        public List<Actor> GetAllActor()
        {
            List<Actor> actor = new List<Actor>();
            actor = db.Actors.ToList();
            return actor;
        }

        public int AddMovie(Movy movie)
        {
            db.Movies.Add(movie);
            int result = db.SaveChanges();
            return movie.MovieId;
        }

        public int UpdateMovie(Movy movie)
        {
           var mov=from mv in db.Movies where mv.MovieId==movie.MovieId select mv;
           var movs = mov.FirstOrDefault();
           movs.MovieId = movie.MovieId;
           movs.MovieName = movie.MovieName;
           movs.MovieRelease = movie.MovieRelease;
           movs.MovieImage = movie.MovieImage;
           movs.Plot = movs.Plot;
            int result = db.SaveChanges();
            return movie.MovieId;
        }

        public int UpdateMovieAct(MovieToActor movieAct)
        {
            var MVtoAc=db.MovieToActors.ToList();
            foreach (var item in MVtoAc)
            {
                
                    if (item.MovieId == movieAct.MovieId && item.ActorId == movieAct.ActorId)
                    {
                        var movToac = from mv in db.MovieToActors where mv.MovieId == item.MovieId && mv.ActorId == item.ActorId select mv;
                        var movac = movToac.FirstOrDefault();
                        movac.Id = movac.Id;
                        movac.MovieId = movieAct.MovieId;
                        movac.ActorId = movieAct.ActorId;

                        int result1 = db.SaveChanges();
                        
                    }
                    else if (item.MovieId != movieAct.MovieId && item.ActorId != movieAct.ActorId)
                    {
                        AddMovieAct(movieAct);
                        // return result;
                    }
               
            }
            int result = db.SaveChanges();
            return result;
        }


        public int UpdateMoviePro(MovieToProducer moviePro)
        {
            var MVtoPc = db.MovieToProducers.ToList();
            foreach (var item in MVtoPc)
            {
                if (item.MovieId == moviePro.MovieId && item.ProducerId == moviePro.ProducerId)
                {
                    var movToac = from mv in db.MovieToProducers where mv.MovieId == item.MovieId && mv.ProducerId == item.ProducerId select mv;
                    var movac = movToac.FirstOrDefault();
                    movac.Id = movac.Id;
                    movac.MovieId = moviePro.MovieId;
                    movac.ProducerId = moviePro.ProducerId;

                    int result1 = db.SaveChanges();
                   
                }
                else if(item.MovieId != moviePro.MovieId && item.ProducerId != moviePro.ProducerId)
                {
                  //  MovieToProducer mvtoPr = new MovieToProducer();
                   
                    AddMoviePro(moviePro);
                    // return result;

                }
            }
            int result = db.SaveChanges();
            return result;
        }

        public int AddMoviePro(MovieToProducer moviePr)
        {
            db.MovieToProducers.Add(moviePr);
            int result = db.SaveChanges();
            return result;
        }

        public int AddMovieAct(MovieToActor movieAct)
        {
            db.MovieToActors.Add(movieAct);
            int result = db.SaveChanges();
            return result;
        }

        public int CheckMovieName(string moviName)
        {
            int count = (from ct in db.Movies where ct.MovieName == moviName select ct).Count();
        return count;

        }
        public int CheckActorName(string ActorName)
        {
            int count = (from ct in db.Actors where ct.ActorName == ActorName select ct).Count();
            return count;

        }

        public int CheckProducerName(string ProducerName)
        {
            int count = (from ct in db.Producers where ct.ProducerName == ProducerName select ct).Count();
            return count;

        }

    }
}