﻿$(document).ready(function () {

    
    $("#SearchBtn").click(function () {
       

        $("#actor").validate({
            errorClass: 'help-block animation-slideDown',
            errorElement: 'div',
            errorPlacement: function (error, e) {
                e.parents('.form-group > div').append(error);
            },
            highlight: function (e) {
                $(e).closest('.form-group').removeClass('has-success has-error').addClass('has-error');
                $(e).closest('.form-control').removeClass('has-success has-error').addClass('has-error');
                $(e).closest('.help-block').remove();
            },
            unhighlight: function (e) {
                $(e).closest('.form-group').removeClass('has-error').addClass('has-success');
                $(e).closest('.help-block').add();
            },
            success: function (e) {
                e.closest('.form-group').removeClass('has-success has-error');
                e.closest('.help-block').remove();
            },
            rules:
            {
                'ActorName':
                    {
                        required: true
                       
                    },
                'Gender':
                    {
                        required: true
                        //minlength: 2
                    },
                'DOB':
                    {
                        required: true
                        //minlength: 2
                    },
                'ActorBio':
                   {
                       required: true
                       //minlength: 2
                   }
                

            },
            messages:
           {
               'MovieName':
              {
                
               

              }

           }

        });
    });
});