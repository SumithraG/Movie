﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MovieWebsite.Models
{
    public class Movies
    {
        [Key]
        public int ActorId { get; set; }

        [Display(Name="Actor Name")]
        [Required(ErrorMessage="Actor Name is Required")]
        public string ActorName { get; set; }

        [Display(Name = "Gender")]
        [Required(ErrorMessage = "Please Select Required")]
        public string Gender { get; set; }

        [Display(Name = "Date of Birth")]
        [Required(ErrorMessage = "This field is required")]
        public System.DateTime DOB { get; set; }

        [Display(Name = "Actor Biography")]
        [Required(ErrorMessage = "This field is required")]
        public string ActorBio { get; set; }

        [Key]
        public int MovieId { get; set; }

        [Display(Name = "Movie Name")]
        [Required(ErrorMessage = "Movie Name is Required")]
        public string MovieName { get; set; }


        [Display(Name = "Year of Release")]
        [Required(ErrorMessage = "This field is required")]
        public System.DateTime MovieRelease { get; set; }

        [Display(Name = "Plot")] 
        public string Plot { get; set; }

        [Display(Name = "Movie Image")]
        [Required(ErrorMessage = "This field is required")]
        public string MovieImage { get; set; }

        [Key]
        public int ProducerId { get; set; }

        [Display(Name = "Producer Name")]
        [Required(ErrorMessage = "This field is required")]
        public string ProducerName { get; set; }

      //  public string Gender { get; set; }
       // public System.DateTime DOB { get; set; }

        [Display(Name = "Producer Biography")]
        [Required(ErrorMessage = "This field is required")]
        public string Bio { get; set; }
    
    }
}