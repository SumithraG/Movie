﻿using MovieWebsite.DAL;
using MovieWebsite.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MovieWebsite.Models;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.IO;

namespace MovieWebsite.Controllers
{
    public class MovieController : Controller
    {
        //
        // GET: /Movie/
        MovieLogics ObjLogics = new MovieLogics();

        public ActionResult Index()
        {
            return View();
        }

        public void bindAllData()
        {
            ViewBag.Producer = new SelectList(ObjLogics.GetAllProducer(), "ProducerId", "ProducerName", "ProducerId");

            List<Gender> gen = new List<Gender>();
            gen.Add(new Gender() { Id = 1, Name = "Female" });
            gen.Add(new Gender() { Id = 2, Name = "Male" });
            ViewBag.Gender = new SelectList(gen, "Id", "Name", "Id");

            ViewBag.Actor = new SelectList(ObjLogics.GetAllActor(), "ActorId", "ActorName", "ActorId");

            DataTable dr = ObjLogics.GetAllActors();
            List<Actors> lstActor = new List<Actors>();
            Actors objActor = new Actors();
            foreach (DataRow dRow in dr.Rows)
            {
                objActor = new Actors();
                objActor.Id = Convert.ToInt32(dRow["ActorId"]);
                objActor.MovieId = Convert.ToInt32(dRow["MovieId"]);
                objActor.Name = dRow["ActorName"].ToString();

                lstActor.Add(objActor);
            }
            ViewBag.Actors = lstActor;
        }
        public ActionResult Movie()
        {
            bindAllData();
            DataTable Movies =ObjLogics.GetAllMovies();
            List<Movies> lstMovies = new List<Movies>();
            Movies objMovies = new Movies();
            foreach (DataRow dRow in Movies.Rows)
            {
                objMovies = new Movies();
                objMovies.ProducerId = Convert.ToInt32(dRow["ProducerId"]);
                objMovies.ProducerName = dRow["ProducerName"].ToString();
                objMovies.MovieName = dRow["MovieName"].ToString();
                objMovies.MovieRelease = Convert.ToDateTime(dRow["MovieRelease"]);
                objMovies.DOB = Convert.ToDateTime(dRow["DOB"]);
                objMovies.MovieId = Convert.ToInt32(dRow["MovieId"]);
                objMovies.Plot = dRow["Plot"].ToString();
                objMovies.MovieImage = "/MoviePhotos/"+dRow["MovieImage"].ToString();
                lstMovies.Add(objMovies);
            }
            ViewBag.Movies = lstMovies;
            return View(objMovies);

        }

        public ActionResult MovieList()
        {

            bindAllData();
            DataTable Movies = ObjLogics.GetAllMovies();
            List<Movies> lstMovies = new List<Movies>();
            Movies objMovies = new Movies();
            foreach (DataRow dRow in Movies.Rows)
            {
                objMovies = new Movies();
                objMovies.ProducerId = Convert.ToInt32(dRow["ProducerId"]);
                objMovies.ProducerName = dRow["ProducerName"].ToString();
                objMovies.MovieName = dRow["MovieName"].ToString();
                objMovies.MovieRelease = Convert.ToDateTime(dRow["MovieRelease"]);
                objMovies.DOB = Convert.ToDateTime(dRow["DOB"]);
                objMovies.MovieId = Convert.ToInt32(dRow["MovieId"]);
                objMovies.Plot = dRow["Plot"].ToString();
                objMovies.MovieImage = "/MoviePhotos/" + dRow["MovieImage"].ToString();
                lstMovies.Add(objMovies);
            }
            ViewBag.Movies = lstMovies;
            return View(lstMovies);
            return View();
        }

        public ActionResult AddMovie()
        {
            bindAllData();
            return View();
        }

        [HttpPost]
        public ActionResult SaveProducer(FormCollection formCollection)
        {
            Producer Objproducer = new Producer();
           
            Objproducer.ProducerId = 0;
            Objproducer.ProducerName = formCollection["ProducerName"].ToString();
            int count = ObjLogics.CheckActorName(Objproducer.ProducerName);
             if (count == 0)
             {
                 Objproducer.Gender = formCollection["Gender"].ToString();
                 Objproducer.DOB = Convert.ToDateTime(formCollection["DOB"].ToString());
                 Objproducer.Bio = formCollection["Bio"].ToString();
                 int result = ObjLogics.AddProducer(Objproducer);
                 bindAllData();
                 TempData["Success"] = "Producer is saved successfully";
                 return RedirectToAction("AddMovie");
             }
             else
             {

                 TempData["Error"] = "Actor is having same name";
                 return RedirectToAction("AddMovie");
             }
            //return View();
        }

        [HttpPost]
        public ActionResult SaveActor(FormCollection formCollection)
        {
            Actor ObjActor = new Actor();

            ObjActor.ActorId = 0;
            ObjActor.ActorName = formCollection["ActorName"].ToString();
            int count = ObjLogics.CheckActorName(ObjActor.ActorName);
            if (count==0)
            {
            ObjActor.Gender = formCollection["Gender"].ToString();
            ObjActor.DOB = Convert.ToDateTime(formCollection["DOB"].ToString());
            ObjActor.ActorBio = formCollection["ActorBio"].ToString();
            int result = ObjLogics.AddActor(ObjActor);
            bindAllData();
            TempData["Success"] = "Actor is saved successfully";
            return RedirectToAction("AddMovie");
            }
            else
            {
            
            TempData["Error"]="Actor is having same name";
            return RedirectToAction("AddMovie");
            }
           // return View();
        }

   //[AcceptVerbs(HttpVerbs.Post)]
        [HttpPost]
        public ActionResult SaveMovie(FormCollection formCollection)
        {
            Movy movi = new Movy();


            if (Convert.ToInt32(Request.Form["MovieId"]) == 0)
            {
                if (Request.Files.Count > 0)
                {


                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        string path = AppDomain.CurrentDomain.BaseDirectory;
                        string filename = Path.GetFileName(Request.Files[i].FileName);

                        HttpPostedFileBase file = files[i];
                        string fname = file.FileName;

                        movi.MovieImage = fname;
                        fname = Path.Combine(Server.MapPath("~/MoviePhotos/"), fname);
                        file.SaveAs(fname);
                    }
                }

                movi.MovieName = Request.Form["MovieName"].ToString();
                int count = ObjLogics.CheckMovieName(movi.MovieName);
                if (count == 0)
                {
                    movi.MovieRelease = Convert.ToDateTime(Request.Form["MovieRelease"].ToString());
                    movi.Plot = "image";
                    int MoviId = ObjLogics.AddMovie(movi);

                    var ActorSelectedIds = Request.Form["ActorIds"].ToString();
                    string[] Actoid = ActorSelectedIds.Split(',').ToArray();

                    MovieToActor mvToAc = new MovieToActor();
                    for (int i = 0; i < Actoid.Length; i++)
                    {
                        mvToAc.MovieId = MoviId;
                        mvToAc.ActorId = Convert.ToInt32(Actoid[i]);
                        int iResult = ObjLogics.AddMovieAct(mvToAc);
                    }


                    MovieToProducer mvToPro = new MovieToProducer();
                    mvToPro.MovieId = MoviId;
                    mvToPro.ProducerId = Convert.ToInt32(Request.Form["ProducerName"]);
                    int moviPrId = ObjLogics.AddMoviePro(mvToPro);
                    TempData["Success"] = "Movie Saved Succesfully";
                    return RedirectToAction("AddMovie");
                }
                else
                {
                    TempData["Error"] = "Having Same Movie Name";
                    //  return View();
                    // TempData["Error"] = "Having Same Movie Name";
                }
            }
            else { 
            
            
            if (Request.Files.Count > 0)
                {


                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        string path = AppDomain.CurrentDomain.BaseDirectory;
                        string filename = Path.GetFileName(Request.Files[i].FileName);

                        HttpPostedFileBase file = files[i];
                        string fname = file.FileName;

                        movi.MovieImage = fname;
                        fname = Path.Combine(Server.MapPath("~/MoviePhotos/"), fname);
                        file.SaveAs(fname);
                    }
                }
                movi.MovieId = Convert.ToInt32(Request.Form["MovieId"]);
                movi.MovieName = Request.Form["MovieName"].ToString();
               
                    movi.MovieRelease = Convert.ToDateTime(Request.Form["MovieRelease"].ToString());
                    movi.Plot = "image";
                    int MoviId = ObjLogics.UpdateMovie(movi);

                    var ActorSelectedIds = Request.Form["ActorIds"].ToString();
                    string[] Actoid = ActorSelectedIds.Split(',').ToArray();

                    MovieToActor mvToAc = new MovieToActor();
                    for (int i = 0; i < Actoid.Length; i++)
                    {
                        mvToAc.MovieId = MoviId;
                        mvToAc.ActorId = Convert.ToInt32(Actoid[i]);
                        int iResult = ObjLogics.UpdateMovieAct(mvToAc);
                    }


                    MovieToProducer mvToPro = new MovieToProducer();
                    mvToPro.MovieId = MoviId;
                    mvToPro.ProducerId = Convert.ToInt32(Request.Form["ProducerName"]);
                    int moviPrId = ObjLogics.UpdateMoviePro(mvToPro);
                    TempData["Success"] = "Movie Saved Succesfully";
                    return RedirectToAction("AddMovie");
            
            
            
            }
            return RedirectToAction("AddMovie");
            
        }

        public ActionResult Edit(int id)
        {
            bindAllData();
            DataTable Movies = ObjLogics.GetMovie(id);
            List<Movies> lstMovies = new List<Movies>();
            Movies objMovies = new Movies();
            foreach (DataRow dRow in Movies.Rows)
            {
                objMovies = new Movies();
                objMovies.ProducerId = Convert.ToInt32(dRow["ProducerId"]);
                objMovies.ProducerName = dRow["ProducerName"].ToString();
                objMovies.MovieName = dRow["MovieName"].ToString();
                objMovies.MovieRelease = Convert.ToDateTime(dRow["MovieRelease"]);
                objMovies.DOB = Convert.ToDateTime(dRow["DOB"]);
                objMovies.MovieId = Convert.ToInt32(dRow["MovieId"]);
                objMovies.Plot = dRow["Plot"].ToString();
                objMovies.MovieImage = "/MoviePhotos/" + dRow["MovieImage"].ToString();
                lstMovies.Add(objMovies);
            }
            ViewBag.Producer = new SelectList(ObjLogics.GetAllProducer(), "ProducerId", "ProducerName", objMovies.ProducerId);
           
            return View(objMovies);
           // return View();
        }
	}
}